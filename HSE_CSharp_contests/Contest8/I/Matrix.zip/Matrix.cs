using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

public class Matrix
{
    public int n, m;
    public int[][] matrix;
    public Matrix(int n, int m)
    {
        this.n = n;
        this.m = m;
        matrix = new int[n][];
    }
    public void ReadMatrix()
    {
        for (int i = 0; i < matrix.Length; i++)
            matrix[i] = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
    }
    public static string operator +(Matrix a, Matrix b)
    {
        if (a.n != b.n || a.m != b.m)
            return "Impossible";
        Matrix c = new Matrix(a.n, a.m);
        for (int i = 0; i < a.n; i++)
        {
            c.matrix[i] = new int[a.m];
            for (int j = 0; j < a.m; j++)
                c.matrix[i][j] = a.matrix[i][j] + b.matrix[i][j];
        }
        return c.ToString();
    }
    public static string operator -(Matrix a, Matrix b)
    {
        if (a.n != b.n || a.m != b.m)
            return "Impossible";
        Matrix c = new Matrix(a.n, a.m);
        for (int i = 0; i < a.n; i++)
        {
            c.matrix[i] = new int[a.m];
            for (int j = 0; j < a.m; j++)
                c.matrix[i][j] = a.matrix[i][j] - b.matrix[i][j];
        }
        return c.ToString();
    }
    public static Matrix operator *(Matrix a, Matrix b)
    {
        if (a.m != b.n)
        {
            Console.Write("Impossible");
            return null;
        }
        Matrix c = new Matrix(a.n, b.m);
        int sum;
        for (int i = 0; i < a.n; i++)
        {
            c.matrix[i] = new int[b.m];
            for (int k = 0; k < b.m; k++)
            {
                sum = 0;
                for (int j = 0; j < a.m; j++)
                {
                    sum += a.matrix[i][j] * b.matrix[j][k];
                }
                c.matrix[i][k] = sum;
            }
        }
        return c;
    }
    public static string operator ~(Matrix a)
    {
        Matrix b = new Matrix(a.m, a.n);
        for (int i = 0; i < a.m; i++)
        {
            for (int j = 0; j < a.n; j++)
            {
                if (j == 0)
                    b.matrix[i] = new int[a.n];
                b.matrix[i][j] = a.matrix[j][i];
            }
        }
        return b.ToString();
    }
    public static string operator ^(Matrix a, int n)
    {
        if (a.n != a.m)
            return "Impossible";
        Matrix c = new Matrix(a.n, a.m);
        for (int i = 0; i < a.n; i++)
        {
            c.matrix[i] = new int[a.m];
            for (int j = 0; j < a.m; j++)
                c.matrix[i][j] = a.matrix[i][j];
        }
        for (int i = 0; i < n - 1; i++)
        {
            c = c * a;
        }
        return c.ToString();
    }

    public static Matrix MinMatr(int[][] matrix, int k)
    {
        int size = matrix.Length - 1;
        int[][] minor = new int[size][];
        List<int> list;
        for (int i = 0; i < size; i++)
        {
            minor[i] = new int[size];
            list = new List<int>();
            for (int j = 0; j < size + 1; j++)
                if (j != k)
                    list.Add(matrix[i + 1][j]);
            for (int j = 0; j < size; j++)
                minor[i][j] = list[j];
        }

        Matrix minMatr = new Matrix(size, size);
        minMatr.matrix = minor;
        return minMatr;
    }

    public static int DetCalc(Matrix a)
    {
        int det = 0;
        int[][] matrix = a.matrix;
        if (a.n == 1)
            return a.matrix[0][0];
        if (a.n == 2)
            return (a.matrix[0][0] * a.matrix[1][1] - a.matrix[0][1] * a.matrix[1][0]);

        for (int i = 0; i < a.m; i++)
            det += (int)Math.Pow(-1, i) * matrix[0][i] * DetCalc(MinMatr(matrix, i));
        return det;
    }
    public static string operator !(Matrix a)
    {
        if (a.n != a.m)
            return "Impossible";
        return DetCalc(a).ToString();

    }
    public override string ToString()
    {
        string str = "";
        foreach (int[] arr in matrix)
        {
            str += string.Join(" ", arr) + "\n";
        }
        return str;
    }
}

