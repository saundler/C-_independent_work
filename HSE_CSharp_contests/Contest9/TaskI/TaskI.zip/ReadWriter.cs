using System;
using System.Collections.Generic;
using System.IO;

internal class ReadWriter
{
    public static (char, char) GetMostAndLeastCommonLetters(string path)
    {
        List<char> charList = new List<char>();
        List<int> intList = new List<int>();
        string str;
        int index, minIndex, n;
        using (StreamReader sr = new StreamReader(path))
        {
            while (!sr.EndOfStream)
            {
                str = sr.ReadLine().ToLower().Replace(" ", "");
                for (int i = 0; i < str.Length; i++)
                {
                    index = charList.FindIndex(a => a == str[i]);
                    if (index != -1)
                    {
                        intList[index]++;
                    }
                    else
                    {
                        charList.Add(str[i]);
                        intList.Add(1);
                    }
                }
            }
        }
        n = intList.Max();
        index = intList.FindIndex(a => a == n);
        n = intList.Min();
        minIndex = intList.FindIndex(a => a == n);
        return (charList[index], charList[minIndex]);
    }

    public static void ReplaceMostRareLetter((char, char) leastAndMostCommon, string inputPath, string outputPath)
    {
        List<(char, int)> list = new List<(char, int)>();
        char[] str;
        using (StreamReader sr = new StreamReader(inputPath))
        using (StreamWriter sw = new StreamWriter(outputPath))
        {
            while (!sr.EndOfStream)
            {
                str = sr.ReadLine().ToCharArray();
                for (int i = 0; i < str.Length; i++)
                {
                    if (str[i].ToString().ToLower() == leastAndMostCommon.Item2.ToString())
                    {
                        str[i] = leastAndMostCommon.Item1;
                    }
                }
                sw.WriteLine(string.Join("", str));
            }
        }
    }
}